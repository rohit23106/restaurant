if(jQuery) {
	alert("We are ready to go!");
}else {
	alert("Error jQuery not found!");
}